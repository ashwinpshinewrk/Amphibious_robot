# Screw vehicle - Webots project

## Open it
1. Install Webots (https://cyberbotics.com).
2. Webots -> File -> Open World... -> `worlds/screw_vehicle.wbt` (uneven terrain)
   or `worlds/screw_vehicle_flat.wbt` (flat floor)
3. Press Play, click inside the 3D view, use the arrow keys: Up/Down = drive forward/back, Left/Right = steer.

## Meshes (worlds/meshes/) - all in metres, X forward, Y left, Z up
| File | Source |
|---|---|
| body.stl | final_assembly_scaled.stl with the 8 old screw parts removed (12 parts kept) |
| screw_left.stl | left_renewed_scaled.stl (origin on the screw axis) |
| screw_right.stl | right_renewed_scaled.stl (origin on the screw axis, stray duplicate removed) |

## Orientation
* Forward (+X in Webots) is the camera / LiDAR / nose-cone end of your robot (+X of your CAD file).
* 'left' and 'right' follow your file names, i.e. as seen in your CAD view from the front. Seen from behind
  the vehicle (the usual Webots way), `left_screw` is therefore on the vehicle's right-hand side (-Y).
* left_renewed has a right-handed thread and right_renewed a left-handed one. They counter-rotate to
  push the same way. If Up-arrow drives backwards (once propulsion exists), flip both signs in the controller.

## Terrain (worlds/screw_vehicle.wbt)
A 6 m x 6 m sand-coloured ElevationGrid (rolling hills, mounds, small roughness; a flat 0.7 m-radius
pad at the centre so the vehicle doesn't spawn on a slope). This is a plain built-in Webots geometry
node, not a PROTO, so it can't fail to load the way an EXTERNPROTO can.
* Height range about -6 cm to +10 cm, steepest slope ~12 degrees.
* Colour: a desert-sand tan (PBRAppearance, no external texture files, so nothing to fail to resolve).
* `worlds/screw_vehicle_flat.wbt` still has a plain flat floor, if you want to test on level ground.
* An earlier version of this file used Webots' built-in `UnevenTerrain` PROTO. It failed to load
  silently in Webots R2025a (the node just didn't appear, with no visible error), so this was
  reverted to a plain ElevationGrid.

## Sand texture
The terrain now uses Webots' built-in `SandyGround` appearance (a real photographic sand texture)
instead of a flat colour, via `EXTERNPROTO "webots://projects/appearances/protos/SandyGround.proto"`.
Only the *appearance* changed, not the terrain shape (still the plain `ElevationGrid` that already
loaded successfully for you) - so even in the worst case where the texture files fail to load, the
terrain itself will still be there, just plain grey instead of textured.

## Amphibious lake (worlds/screw_vehicle.wbt only)
The sandy terrain now has a lake carved into it on the +X side (the vehicle's front/forward side):
* Shoreline starts at x = 1.2 m, the lake bed flattens out at x = 2.2 m at a depth of 0.25 m below
  the sand level, giving the vehicle a slope to drive down into the water.
* The water itself is a Webots `Fluid` node (density 1000 kg/m^3 = fresh water), with a separate
  translucent blue `Shape` on top so you can actually see it.
* `ImmersionProperties` were added to the hull and to both screws, so each gets real Archimedes'
  buoyancy and drag based on its own collision-shape volume (the box for the hull, the cylinders for
  the screws) once it's underwater or partly submerged - this is what should let the screw-driven
  buoyancy your design doc described actually work in the simulation.
* This is new and I have not been able to test it myself. Webots' `Fluid` node has had crash bug
  reports in the past when combined with certain boundingObject shapes, though none this specific setup
  (a plain Box) has been reported recently. If Webots crashes or behaves oddly when you open this,
  tell me and I'll simplify it (e.g. drop the physics and keep just a visual lake).
* `worlds/screw_vehicle_flat.wbt` is unchanged (flat floor, no lake, no Fluid).

## Placeholders
* Masses (4 kg body, 1.5 kg per screw), colours, floor and lighting are placeholders.
* Collision shapes are simple (box + cylinders) on purpose.

## How driving works (simplified model)
Real screw propulsion comes from the thread pushing against soft ground or water. A rigid-body simulator
cannot reproduce that from a smooth collision cylinder, so the controller applies a forward force at each
screw and regulates it (PI controller in `controllers/screw_controller/screw_drive.py`) to reach a target
speed and turn rate. The screws still spin visibly, but the thrust is an approximation.
* Tuning knobs are at the top of `screw_controller.py`: MAX_SPEED_MPS, MAX_YAW_RATE, F_SCREW_MAX.
* Set `USE_SIMPLE_THRUST = False` to get spinning screws only.
* The screws use a low-friction contact material (0.5) defined in the world's WorldInfo.
* Water (buoyancy, drag) is NOT modelled - this is a land model.
* This has not been run in Webots by the author of this package: expect to tune the numbers.
