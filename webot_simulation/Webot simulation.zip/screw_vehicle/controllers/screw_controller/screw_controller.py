"""Keyboard controller for the screw vehicle.

Click inside the 3D view first so it receives keystrokes, then:
    UP / DOWN     -> drive forward / backward   (forward = the camera / LiDAR end)
    LEFT / RIGHT  -> steer
    (release keys -> the vehicle brakes and holds its position)

Both screws spin as commanded. The driving force itself comes from a SIMPLIFIED propulsion model
(see screw_drive.py), not from real thread-on-ground contact. Set USE_SIMPLE_THRUST = False to turn it
off and get spinning screws only.
"""
from controller import Supervisor, Keyboard
from screw_drive import ThrustController

USE_SIMPLE_THRUST = True

# ---- tuning knobs ---------------------------------------------------------------------------
MAX_SPEED_MPS = 0.25        # forward speed at full command
MAX_YAW_RATE = 0.6          # rad/s turn rate at full command
F_SCREW_MAX = 60.0          # N, maximum thrust of one screw
SCREW_VISUAL_RAD_S = 8.0    # how fast the screws visibly turn at full thrust
# Screws are counter-rotating (right-handed thread on 'left', left-handed on 'right'), so opposite signs.
# If the screws look like they turn the wrong way, flip BOTH signs.
LEFT_SIGN, RIGHT_SIGN = 1.0, -1.0
# ---------------------------------------------------------------------------------------------

HALF_TRACK = 0.20263        # m, screw centre-line distance from the vehicle's centre-line
FORCE_HEIGHT = -0.06        # m, thrust is applied near ground level (relative to the screw axis)

robot = Supervisor()
dt_ms = int(robot.getBasicTimeStep())
dt = dt_ms / 1000.0
me = robot.getSelf()

# NOTE on names: 'left' / 'right' follow your CAD files (as seen from the FRONT). Seen from behind the vehicle,
# the 'left' screw is on the vehicle's RIGHT-hand side (-Y) and the 'right' screw on its LEFT-hand side (+Y).
motor_at_minus_y = robot.getDevice("left_screw_motor")
motor_at_plus_y = robot.getDevice("right_screw_motor")
for motor in (motor_at_minus_y, motor_at_plus_y):
    motor.setPosition(float("inf"))   # velocity-control mode
    motor.setVelocity(0.0)

keyboard = robot.getKeyboard()
keyboard.enable(dt_ms)

drive = ThrustController(v_max=MAX_SPEED_MPS, w_max=MAX_YAW_RATE, f_screw_max=F_SCREW_MAX, half_track=HALF_TRACK)
print(__doc__)

while robot.step(dt_ms) != -1:
    forward, turn = 0.0, 0.0
    key = keyboard.getKey()
    while key != -1:
        if key == Keyboard.UP:
            forward += 1.0
        elif key == Keyboard.DOWN:
            forward -= 1.0
        elif key == Keyboard.RIGHT:
            turn += 1.0
        elif key == Keyboard.LEFT:
            turn -= 1.0
        key = keyboard.getKey()
    forward = max(-1.0, min(1.0, forward))
    turn = max(-1.0, min(1.0, turn))

    # current forward speed (along the vehicle's own X axis) and yaw rate
    vel = me.getVelocity()            # [vx, vy, vz, wx, wy, wz] in world coordinates
    rot = me.getOrientation()         # 3x3 rotation matrix, row-major; first column = vehicle X axis in the world
    v_fwd = vel[0] * rot[0] + vel[1] * rot[3] + vel[2] * rot[6]
    yaw_rate = vel[5]

    f_plus_y, f_minus_y = drive.update(v_fwd, yaw_rate, forward, turn, dt)

    if USE_SIMPLE_THRUST:
        me.addForceWithOffset([f_plus_y, 0.0, 0.0], [0.0, HALF_TRACK, FORCE_HEIGHT], True)
        me.addForceWithOffset([f_minus_y, 0.0, 0.0], [0.0, -HALF_TRACK, FORCE_HEIGHT], True)

    motor_at_minus_y.setVelocity(LEFT_SIGN * SCREW_VISUAL_RAD_S * f_minus_y / F_SCREW_MAX)
    motor_at_plus_y.setVelocity(RIGHT_SIGN * SCREW_VISUAL_RAD_S * f_plus_y / F_SCREW_MAX)
