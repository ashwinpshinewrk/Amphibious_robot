"""Simplified propulsion model for a twin-screw vehicle (pure Python, no Webots imports).

Real screw propulsion comes from the helical thread pushing against soft ground or water. A rigid-body
simulator cannot get that from a smooth collision cylinder, so instead we apply a forward force at each
screw and regulate it with a PI controller so the vehicle reaches a target forward speed and yaw rate.

Conventions (Webots FLU): +X forward, +Y left, +Z up.  turn_cmd > 0 means "turn right" (clockwise, yaw rate < 0).
"""


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


class ThrustController:
    def __init__(self, v_max=0.25, w_max=0.6, f_screw_max=60.0, half_track=0.20263,
                 kp_v=120.0, ki_v=250.0, kp_w=4.0, ki_w=8.0):
        self.v_max, self.w_max = v_max, w_max                  # m/s, rad/s at full command
        self.f_max = f_screw_max                               # N per screw
        self.d = half_track                                    # m, lateral distance of each screw from centreline
        self.kp_v, self.ki_v, self.kp_w, self.ki_w = kp_v, ki_v, kp_w, ki_w
        self.reset()

    def reset(self):
        self.iv = 0.0
        self.iw = 0.0

    def update(self, v_fwd, w_yaw, forward_cmd, turn_cmd, dt):
        """Returns (force_left_side, force_right_side) in newtons along +X.
        'left side' is the screw at +Y, 'right side' the screw at -Y (vehicle's own left/right, seen from behind)."""
        idle = forward_cmd == 0 and turn_cmd == 0
        if idle and abs(v_fwd) < 0.02 and abs(w_yaw) < 0.05:
            self.reset()
            return 0.0, 0.0
        v_t = self.v_max * forward_cmd
        w_t = -self.w_max * turn_cmd
        ev, ew = v_t - v_fwd, w_t - w_yaw
        self.iv = _clamp(self.iv + self.ki_v * ev * dt, -2 * self.f_max, 2 * self.f_max)
        self.iw = _clamp(self.iw + self.ki_w * ew * dt, -2 * self.f_max * self.d, 2 * self.f_max * self.d)
        force = self.kp_v * ev + self.iv                       # total forward force
        torque = self.kp_w * ew + self.iw                      # yaw torque about +Z
        # a force Fx applied at lateral offset y gives torque -y*Fx about Z
        f_left = force / 2 - torque / (2 * self.d)             # screw at +Y
        f_right = force / 2 + torque / (2 * self.d)            # screw at -Y
        return _clamp(f_left, -self.f_max, self.f_max), _clamp(f_right, -self.f_max, self.f_max)
